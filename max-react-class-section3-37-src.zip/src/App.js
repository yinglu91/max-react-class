import ExpenseList from './components/ExpenseList'

const App = () => {
  return (
    <div>
      <h2>Let's get started!</h2>
      <ExpenseList />
    </div>
  )
}

export default App
